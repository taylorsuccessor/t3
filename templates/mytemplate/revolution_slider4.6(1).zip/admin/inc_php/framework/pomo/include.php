<?php
require_once dirname(__FILE__) . '/mo.php';
require_once dirname(__FILE__) . '/entry.php';
require_once dirname(__FILE__) . '/translations.php';
