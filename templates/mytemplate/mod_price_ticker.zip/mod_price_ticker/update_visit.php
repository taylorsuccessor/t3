<?php
include 'includes/connection.php';
$visit_id = $_REQUEST['visit_id'];
$date = $_POST['date'];
$history = $_POST['history'];
$diagnosis = $_POST['diagnosis'];
$payment_method = $_POST['payment_method'];
$company_name = $_POST['company_name'];
$test = $_POST['test'];
$drugs = $_POST['drugs'];
$sql = "update visits set date = '$date',"
        . "history='$history' ,diagnosis= '$diagnosis',payment_method= '$payment_method',"
        . "company_name= '$company_name', test= '$test',drugs= '$drugs' where visit_id = $visit_id ";

$result = mysqli_query($conn, $sql);
if ($result) {
    header("location:visits.php");
} else {
    die("Error");
}
