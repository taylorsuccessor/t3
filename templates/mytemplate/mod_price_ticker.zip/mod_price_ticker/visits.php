<?php include 'includes/header.php';
include 'includes/connection.php';
?>
<h1>Manage Visits</h1>
<form method="post" action="visits.php" >
    Search Patients <input type="text" name="vname" autocomplete="off" > 
    <input type="submit" name="search" value="Search"> 
</form>
<form method="post" action="visits.php">  
    <select name="patient_id" style="width: 283px" size="5" >
        <?php
        if (isset($_POST['search'])) {
            echo '<br>';
            $search = $_POST['vname'];
            $sql = "select * from patients where name like '%$search%' order by name limit 5";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<option value="' . $row['patient_id'] . '">' . $row['name'] . '</option>';
                }
            }
        }
        ?>
    </select>
    <input type="submit" name="select" value="Select">
</form>   
<?php
$patient_id = "";
if (isset($_SESSION['id']))
    $patient_id = $_SESSION['id'];
if (!empty($_POST['patient_id'])) {
    if (isset($_POST['select'])) {
        $patient_id = $_POST['patient_id'];
        $_SESSION['id'] = $patient_id;
    }
}
$sql1 = "select * from patients where patient_id='$patient_id'";
$result1 = mysqli_query($conn, $sql1);
if ($row1 = mysqli_fetch_assoc($result1)) {
    echo "<b>Patient Name : " . $row1['name'] . "</b>";
    echo '<br><ul><li><a href="add_visit.php">Add Visit</a></li></ul>';

    $sql2 = "select * from visits where patient_id='$patient_id'";
    $result2 = mysqli_query($conn, $sql2);
    if ($result2) {
        echo '<table border="2" width="100%">';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>Date</th>';
        echo '<th>History</th>';
        echo '<th>Diagnosis</th>';
        echo '<th>Payment Method</th>';
        echo '<th>Company Name</th>';
        echo '<th>Tests Result</th>';
        echo '<th>Drugs</th>';
        echo '<th>Edit</th>';
        echo '<th>Delete</th>';
        echo '</tr>';
        while ($row2 = mysqli_fetch_assoc($result2)) {
            echo "<tr>";
            echo "<td>{$row2['visit_id']}</td>";
            echo "<td>{$row2['date']}</td>";
            echo "<td>{$row2['history']}</td>";
            echo "<td>{$row2['diagnosis']}</td>";
            echo "<td>{$row2['payment_method']}</td>";
            echo "<td>{$row2['company_name']}</td>";
            echo "<td>{$row2['test']}</td>";
            echo "<td>{$row2['drugs']}</td>";
            echo "<td><a href ='edit_visit.php?visit_id={$row2['visit_id']}'>Edit</a></td>";
            echo "<td><a href ='delete_visit.php?visit_id={$row2['visit_id']}'>Delete</a></td>";
            echo "</tr>";
        }
        echo'</table>';
    }
}
include 'includes/footer.php';
?>
